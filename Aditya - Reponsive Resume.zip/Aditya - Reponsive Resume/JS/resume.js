document.addEventListener("DOMContentLoaded", function() {
  const menu = document.getElementById("menu");
  const header = document.querySelector("header");
  const topButton = document.querySelector(".top");

  menu.addEventListener("click", () => {
    menu.classList.toggle("fa-times");
    header.classList.toggle("toggle");
  });

  function handleScroll() {
    menu.classList.remove("fa-times");
    header.classList.remove("toggle");
    topButton.style.display = window.scrollY > 0 ? "block" : "none";
  }

  window.addEventListener("scroll", handleScroll);
  window.addEventListener("load", handleScroll);

  document.querySelectorAll('a[href*="#"]').forEach(link => {
    link.addEventListener("click", event => {
      event.preventDefault();
      const targetId = link.getAttribute("href").substring(1);
      const targetElement = document.getElementById(targetId);
      if (targetElement) {
        const targetOffsetTop = targetElement.getBoundingClientRect().top + window.scrollY;
        window.scrollTo({
          top: targetOffsetTop,
          behavior: "smooth"
        });
      }
    });
  });
});
